# Twin-city-web-application
Create a web application based on 2 twin cities, where i gather data from APIs and/or a database
